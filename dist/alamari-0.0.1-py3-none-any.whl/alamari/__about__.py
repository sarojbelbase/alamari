__package_name__ = 'alamari'
__version__ = '0.0.1'
__author__ = 'Siddharth Belbase'
__author_email__ = 'siddharthbelbase@gmail.com'
__description__ = (
    'A collection of utils that you might not require but might need.')
__url__ = 'https://github.com/sidbelbase/alamari'
